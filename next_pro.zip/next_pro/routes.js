const routes = require('next-routes');
module.exports = routes()
     
